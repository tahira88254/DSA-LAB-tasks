#include<iostream>
using namespace std;
int main()
{
	int a=5;
	char b= 'a';
	float c=2.2;
	double d=20.20;
	void *ptr;
	ptr = &a;
	cout<<"Integer: "<<*(int*)ptr <<endl;
	ptr = &b;
	cout<<"Character: "<<*(char*)ptr <<endl;
	ptr = &c;
	cout<<"float: "<<*(float*)ptr <<endl;
	ptr = &d;
	cout<<"double: "<<*(double*)ptr <<endl;
	return 0;
}