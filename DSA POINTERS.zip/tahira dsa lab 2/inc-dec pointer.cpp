#include <iostream>
using namespace std;

int main() {
    int arr[] = {10, 20, 30, 40, 50};
    int *ptr = arr; 

    cout << "Initial Pointer Value: " << *ptr << endl;

    ptr++;
    cout << "After Increment: " << *ptr << endl;

    ptr--;
    cout << "After Decrement: " << *ptr << endl;

    ptr += 2;
    cout << "After Adding 2: " << *ptr << endl;

    ptr -= 1;
    cout << "After Subtracting 1: " << *ptr << endl;

    return 0;
}
