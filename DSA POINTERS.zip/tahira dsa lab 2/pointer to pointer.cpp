#include <iostream>  
using namespace std;

int main() {
    int a,b;          
    int *ptr1 = &a;   
     int *ptr2 = &b;
    int **q = &ptr1;  
    int **p = &ptr2; 
    // Prompt the user to enter a value for a and b
    cout << "Enter the value of a and b: "<<endl;
    cin >> a>> b;  

    // Output the value stored in 'a' using the pointer 'ptr'
    cout << "The value of ptr1 (value of a) is: " << *ptr1 << endl;

    // Output the value stored in 'a' using the pointer-to-pointer 'q'
    cout << "The value of **q (value of a) is: " << **q << endl;

 // Output the value stored in 'b' using the pointer 'ptr'
    cout << "The value of ptr2 (value of b) is: " << *ptr2 << endl;

    // Output the value stored in 'b' using the pointer-to-pointer 'q'
    cout << "The value of **q (value of b) is: " << **p << endl;
    return 0; 
}

