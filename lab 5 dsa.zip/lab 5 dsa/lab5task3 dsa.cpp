#include<iostream>
#include<string>
using namespace std;
struct Player
{
    string name;
    int score;
    Player* next;
    Player* prev;
    Player(string playerName,int playerScore)
	{
        name=playerName;
        score=playerScore;
        next=prev=nullptr;
    }
};
void insertPlayer(Player*& head,string name,int score)
{
    Player* newPlayer=new Player(name,score);
    if(!head || score<head->score)
	{ 
        newPlayer->next=head;
        if(head)head->prev=newPlayer;
        head = newPlayer;
        return;
    }
    Player* temp=head;
    while(temp->next && temp->next->score<=score)
	{
        temp=temp->next;
    }
    newPlayer->next=temp->next;
    if(temp->next)temp->next->prev=newPlayer;
    temp->next=newPlayer;
    newPlayer->prev=temp;
}
void displayPlayers(Player* head)
{
    if(!head)
	{
        cout<<"No players in the list.\n";
        return;
    }
    cout<<"Players and Scores:\n";
    while(head)
	{
        cout<<head->name<<" - "<<head->score<<endl;
        head=head->next;
    }
}
int main()
{
    Player* head=nullptr;
    int choice;
    do
	{
        cout<<"\n1. Add Player\n2. Display Players\n3. Exit\nEnter choice: ";
        cin>>choice;
        if(choice==1)
		{
            string name;
            int score;
            cout<<"Enter player name: ";
            cin>>name;
            cout<<"Enter player score: ";
            cin>>score;
            insertPlayer(head,name,score);
        } 
        else if(choice==2)
		{
            displayPlayers(head);
        }
	}
	while(choice!=3);
    return 0;
}